//: Playground - noun: a place where people can play

import UIKit

enum StudentYear: Int {
    case freshman, sophomore, junior, senior
}

struct Student {
    let firstName: String
    let lastName: String
    let id: Int
    let year: StudentYear
    let grade: Int
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.id  = Int(arc4random_uniform(1000))
        self.year = StudentYear(rawValue: Int(arc4random_uniform(4))) ?? .freshman
        self.grade = Int(arc4random_uniform(101))
    }
}

var students: [Student] = [
    Student(firstName: "Sterling", lastName: "Archer"),
    Student(firstName: "Lana", lastName: "Kane"),
    Student(firstName: "Cheryl", lastName: "Tunt"),
    Student(firstName: "Pam", lastName: "Poovey"),
    Student(firstName: "Cyril", lastName: "Figgis"),
    Student(firstName: "Ray", lastName: "Gillette"),
    Student(firstName: "Malory", lastName: "Archer"),
    Student(firstName: "Barry", lastName: "Dillon"),
    Student(firstName: "Ron", lastName: "Cadillac"),
    Student(firstName: "Ross", lastName: "Geller"),
    Student(firstName: "Chandler", lastName: "Bing"),
    Student(firstName: "Rachel", lastName: "Green"),
    Student(firstName: "Joey", lastName: "Tribbiani"),
    Student(firstName: "Monica", lastName: "Geller"),
    Student(firstName: "Phoebe", lastName: "Buffay")
]

// TODO: - Create an array that contains only the freshmen from the student array using the filter function
//var freshie = students.filter({ student -> Bool in
//we dont need to surround the if statement with parenthesis in Swift
//    if student.year == StudentYear.freshman  {
//        return true;
//    }
//    else {
//        return false;
//    }
//})

//$0 means the first parameter. $1 would be for the second parameter and so on
//since we are using students.filter, it can assume we are of type student
//so we dont need student -> Bool part
//If $0.year ==.freshman then it will return true and if not return false
//Dont need to include the in keyword as we only have one line we need to do
//we can declare var freshie and inference will happen so freshie will become an array
var freshie = students.filter { $0.year == .freshman }

//Testing
for element in freshie {
    print(element)
}




// TODO: - Create an array that contains only the full names (first name concatenated with the last name) from the student array using the map function

//Normie Version
//let fullNames = students.map(firstname + lastname)
//var fullNames = students.map { (student) -> String in
//    return student.firstName + student.lastName
//}

//Refactored Version
var fullNames = students.map {$0.firstName + " " + $0.lastName}

//Testing
for element in fullNames {
    print(element)
}




// TODO: - Return the average grade from all the students using the reduce function divided by the count

//Normie Version
//var averageGrade = students.reduce(0) { (accumulator, student) -> Int in
//    return accumulator + student.grade
//}

//Refactored Version
var totalGrade = students.reduce(0, { $0 + $1.grade })

var averageGrade = totalGrade / students.count

//Testing
print(averageGrade)
