import UIKit

enum StatusCode: String {
    case success
    case unauthorized
    case forbidden
    case notFound
}

func prettyPrint(enumValue: StatusCode) -> String {
    switch enumValue {
    case .success:
        return "200: Success"
    case .unauthorized:
        return "401: Unauthorized"
    case .forbidden:
        return "403: Forbidden"
    case .notFound:
        return "404: Not Found"
        
        //No default?
    }
}

//Testing
prettyPrint(enumValue: .success)

prettyPrint(enumValue: .notFound)
