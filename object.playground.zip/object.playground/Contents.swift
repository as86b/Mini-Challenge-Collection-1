import UIKit

class Dog {
    
    var name: String
    var owner: String
    var age: Int
    
    init() {
        name = "Orion"
        owner = "Dale"
        age = 4
    }
    
    //Is it void by default?
    func bark() {
        print("Woof")
    }
    
    //Didnt need a setter. Setter was originally blank
    //Since we only were using a getter, we can refactor into this
    var dogTag: String {
        return "If lost, call " + name
    }
}

//Testing
let puppy = Dog()
puppy.bark() // Prints "Woof"
print(puppy.dogTag) // Prints "If lost, call Shawn
