import UIKit

func something(v1: Double, v2: Double) -> Double {
    return v1 + v2
}

struct MathOperation {
    var units: String
    
    var operation: (Double, Double) -> Double
    
    init?(units: String) {
        if units.isEmpty {
            return nil
        }
        
        self.units = units
        
        self.operation = something
    }
}

//Testing
let x = MathOperation(units: "units")

x?.operation(2.3, 4.5)

var test = MathOperation(units: "")
