import UIKit

func check(_: Int) -> String? {
    if(value < 0 || value == 0)
    {
        return nil
    }
    else {
        print(value)
        return "value"
    }
}

var value = 10

var test = check(value)

//Since check returns an Optional string, we need to handle the case if var test is nil
//If test returns nil, we will instead print the word Nil
print("\( test ?? "Nil" )")
