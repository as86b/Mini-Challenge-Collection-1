import UIKit

enum StatusCode: Int {
    case success = 200
    case unauthorized = 401
    case forbidden = 403
    case notFound = 404
}

func prettyPrint(enumValue: StatusCode) -> String {
    switch enumValue {
    case .success:
        return "\(enumValue.rawValue)" + " Success"
    case .unauthorized:
        return "\(enumValue.rawValue)" + " Unauthorized"
    case .forbidden:
        return "\(enumValue.rawValue)" + " Forbidden"
    case .notFound:
        return "\(enumValue.rawValue)" + " Not Found"
        
    //No default?
    }
}

//Testing
prettyPrint(enumValue: .success)

prettyPrint(enumValue: .unauthorized)

prettyPrint(enumValue: .forbidden)

prettyPrint(enumValue: .notFound)
